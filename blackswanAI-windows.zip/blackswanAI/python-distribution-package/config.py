binance_api_key = ''
binance_api_secret = ''

bitmex_api_key = ''
bitmex_api_secret = ''

bybit_api_key = ''
bybit_api_secret = ''

kucoin_api_key = ''
kucoin_api_secret = ''
kucoin_api_pass = ""



openai_api_key = ''

twitter_user_login = ''
twitter_user_password = ''
twitter_user_email = ''
twitter_users_to_scrape = ("WatcherGuru", "VitalikButerin", "cz_binance", "GaryGensler", "DeItaone", "zoomerfield")
twitter_keyterms_to_scrape = ("hack", "bank", "war", "collapse", "exchange", "bankrupt", "insolvent" )
twitter_minimum_followers_termscrape = 20000 # If you do not wish to trade on search terms simply set this to an extremely high number
