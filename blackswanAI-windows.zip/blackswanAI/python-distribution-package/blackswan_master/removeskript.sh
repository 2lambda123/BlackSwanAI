#!/bin/bash

while read -r package; do
    pip3.10 uninstall -y "$package"
done < requirements.txt

