import base64
import json
import time
import traceback
from typing import Any, Dict, List, Tuple

from twitter.login import load_session, login
from twitter.scraper import Scraper
from twitter.search import Search

from blackswan.utils import *


def connect(email: str, username: str, password: str) -> Tuple[Scraper, Search]:
    session = load_session()
    if not session:
        session = login(email, username, password)
    if not session:
        raise Exception("Saved session doesn't exist and login failed!")
    return Scraper.from_login(session, debug=True, save=False), Search.from_login(
        session, save=False
    )


def parse_user_data(user_data: Dict[str, Any]) -> Dict[str, Any]:
    user_screen_name = user_data["legacy"]["screen_name"]
    user_id = user_data["id"]
    return {
        "screen_name": user_screen_name,
        "user_id": int(base64.b64decode(user_id).decode().split(":")[1]),
        "followers": user_data["legacy"]["followers_count"],
    }


def get_user_by_screen_name(scraper: Scraper, user_screen_name: str) -> Dict[str, Any]:
    """Returns a dictionary object representing a user"""
    user_info = scraper.users([user_screen_name])
    user_data = user_info[0][0]["data"]["user"]["result"]
    return parse_user_data(user_data)


def parse_tweet_data(
    scraper, tweet_data: Dict[str, Any], user_data: Dict[str, Any]
) -> Dict[str, Any]:
    # handle RT
    if "retweeted_status_result" in tweet_data:
        try:
            rt_tweet_data = tweet_data["retweeted_status_result"]["result"]["legacy"]
        except:
            rt_tweet_data = tweet_data["retweeted_status_result"]["result"]["tweet"][
                "legacy"
            ]
        return {
            "text": rt_tweet_data["full_text"],
            "favorites": rt_tweet_data["favorite_count"],
            "retweets": rt_tweet_data["retweet_count"],
            "cashtags": [
                f"${symbol['text']}" for symbol in rt_tweet_data["entities"]["symbols"]
            ],
            "tweet_id": int(tweet_data["id_str"]),
            "created_at": tweet_data["created_at"],
            "extra_tweet_info": {
                "is_retweet": True,
                "original_user_id": int(rt_tweet_data["user_id_str"]),
                "original_tweet_id": int(rt_tweet_data["id_str"]),
                "original_created_at": rt_tweet_data["created_at"],
            },
            "user_info": user_data,
        }
    # handle quote tweet RT
    # this will be called recursively and can nest many tweets
    # TODO: test with a big thread
    elif tweet_data["is_quote_status"]:
        quoted_tweet_id = int(tweet_data["quoted_status_id_str"])
        return {
            "text": tweet_data["full_text"],
            "favorites": tweet_data["favorite_count"],
            "retweets": tweet_data["retweet_count"],
            "cashtags": [
                f"${symbol['text']}" for symbol in tweet_data["entities"]["symbols"]
            ],
            "tweet_id": int(tweet_data["id_str"]),
            "created_at": tweet_data["created_at"],
            "extra_tweet_info": {
                "is_quote": True,
                "quote_tweet": get_tweet_by_id(scraper, quoted_tweet_id),
            },
            "user_info": user_data,
        }
    # normal tweet
    return {
        "text": tweet_data["full_text"],
        "favorites": tweet_data["favorite_count"],
        "retweets": tweet_data["retweet_count"],
        "cashtags": [
            f"${symbol['text']}" for symbol in tweet_data["entities"]["symbols"]
        ],
        "tweet_id": int(tweet_data["id_str"]),
        "created_at": tweet_data["created_at"],
        "extra_tweet_info": None,
        "user_info": user_data,
    }


def get_tweet_by_id(scraper: Scraper, tweet_id: int) -> Dict[str, Any]:
    """
    Scrapes a single tweet by the id, this can be found at the end of a tweet url
    ex) https://twitter.com/sama/status/1599671496636780546
    """
    tweet_content = scraper.tweets_by_id([tweet_id])[0][0]["data"]["tweetResult"][
        "result"
    ]
    try:
        tweet_data = tweet_content["legacy"]
    except:
        try:
            tweet_data = tweet_content["tweet"]["legacy"]
        except:
            print(f"Error getting tweet data: {tweet_content['reason']}")
            return {}
    try:
        user_data = parse_user_data(tweet_content["core"]["user_results"]["result"])
    except:
        user_data = parse_user_data(
            tweet_content["tweet"]["core"]["user_results"]["result"]
        )
    return parse_tweet_data(scraper, tweet_data, user_data)


def get_user_timeline(scraper: Scraper, user_screen_name: str) -> List[Dict[str, Any]]:
    """
    Grabs every tweet for the specified user, returned as a list of dictionary objects
    """
    user_data = get_user_by_screen_name(scraper, user_screen_name)

    timeline = scraper.tweets([user_data["user_id"]])[0]
    user_tweets = []
    tweets_maybe = timeline[0]["data"]["user"]["result"]["timeline_v2"]["timeline"][
        "instructions"
    ]
    if "entries" in tweets_maybe[0]:
        tweets = tweets_maybe[0]
    else:
        tweets = tweets_maybe[1]
    for tweet in tweets["entries"]:
        tweet_content = tweet["content"]
        if "itemContent" not in tweet_content:
            continue  # other timeline object ignore for now
        try:
            tweet_data = tweet_content["itemContent"]["tweet_results"]["result"][
                "legacy"
            ]
        except:
            tweet_data = tweet_content["itemContent"]["tweet_results"]["result"][
                "tweet"
            ]["legacy"]
        user_tweets.append(parse_tweet_data(scraper, tweet_data, user_data))
    return user_tweets


def sort_and_filter_tweets(
    tweets: List[Dict[str, Any]], ts_ms: int | None = None
) -> List[Dict[str, Any]]:
    sorted_tweets = sorted(
        tweets,
        key=lambda x: datetime.strptime(x["created_at"], "%a %b %d %H:%M:%S %z %Y"),
    )
    if ts_ms is None:
        return sorted_tweets
    # filter tweet results by created_at so only results newer than ts are returned
    return [
        item
        for item in sorted_tweets
        if int(
            datetime.strptime(item["created_at"], "%a %b %d %H:%M:%S %z %Y").timestamp()
            * 1000
        )
        > ts_ms
    ]


def get_tweets_from_user_since(
    scraper: Scraper,
    user_screen_name: str,
    ts_ms: int | None = None,
    sleep_interval: int = 10,
) -> List[Dict[str, Any]]:
    """
    Returns tweets by the specified user since the unix timestamp (or their latest timeline results if None)
    If no tweets are immediately available, this function will loop
    sleeping `sleep_interval` seconds between each check, and return as soon as a tweet is available
    """
    # scrape user's timeline
    tweets = []
    while not tweets:
        tweets = sort_and_filter_tweets(
            get_user_timeline(scraper, user_screen_name), ts_ms
        )
        if tweets:
            break
        time.sleep(sleep_interval)

    return tweets


def search_tweets(
    scraper: Scraper, search: Search, query: str, limit: int = 1
) -> List[Dict[str, Any]]:
    """
    Searches for the latest tweets globally matching the filter, returns `limit` results
    this will sleep and retry until `limit` tweets are found!
    """

    # for safety / ease of use always include `since: YYYY-MM-DD` where the date is TODAY.
    search_results = search.run(
        query + f" since:{datetime.today().strftime('%Y-%m-%d')}",
        limit=limit,
        latest=True,
    )
    if not search_results:
        return []

    search_tweet_data = search_results[0][0]["globalObjects"]["tweets"]

    tweets = []
    for tweet_id, _ in search_tweet_data.items():
        tweets.append(get_tweet_by_id(scraper, tweet_id))

    return tweets
